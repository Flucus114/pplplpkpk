package com.devourervoid.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class VoidCrystalParticle extends TextureSheetParticle {

    protected VoidCrystalParticle(ClientLevel level, double x, double y, double z,
                                   double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        this.lifetime   = 15 + random.nextInt(10);
        this.gravity    = -0.01f;
        this.hasPhysics = false;
        // roxo cosmico
        this.rCol = 0.67f; this.gCol = 0.42f; this.bCol = 1.0f;
        this.alpha    = 0.9f;
        this.quadSize = 0.06f + random.nextFloat() * 0.05f;
    }

    @Override
    public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    @OnlyIn(Dist.CLIENT)
    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }
        @Override
        public Particle createParticle(SimpleParticleType t, ClientLevel level,
                                       double x, double y, double z,
                                       double vx, double vy, double vz) {
            VoidCrystalParticle p = new VoidCrystalParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites); return p;
        }
    }
}
