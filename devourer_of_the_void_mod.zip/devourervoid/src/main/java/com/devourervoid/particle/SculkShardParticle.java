package com.devourervoid.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SculkShardParticle extends TextureSheetParticle {

    protected SculkShardParticle(ClientLevel level, double x, double y, double z,
                                  double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        this.lifetime   = 20 + random.nextInt(15);
        this.gravity    = 0.04f;
        this.hasPhysics = true;
        this.rCol = 0.04f; this.gCol = 0.16f; this.bCol = 0.23f;
        this.quadSize = 0.12f + random.nextFloat() * 0.08f;
    }

    @Override
    public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_OPAQUE; }

    @OnlyIn(Dist.CLIENT)
    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }
        @Override
        public Particle createParticle(SimpleParticleType t, ClientLevel level,
                                       double x, double y, double z,
                                       double vx, double vy, double vz) {
            SculkShardParticle p = new SculkShardParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites); return p;
        }
    }
}
