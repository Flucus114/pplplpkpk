package com.devourervoid.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CosmicEnergyParticle extends TextureSheetParticle {

    protected CosmicEnergyParticle(ClientLevel level, double x, double y, double z,
                                   double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        this.lifetime   = 30 + random.nextInt(20);
        this.gravity    = -0.02f;
        this.hasPhysics = false;
        this.rCol = 0.0f; this.gCol = 0.9f; this.bCol = 1.0f;
        this.alpha    = 0.8f;
        this.quadSize = 0.08f + random.nextFloat() * 0.06f;
    }

    @Override
    public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    @Override
    public void tick() {
        super.tick();
        this.alpha = 0.4f + 0.4f * (float) Math.sin(Math.PI * age / (double) lifetime);
    }

    @OnlyIn(Dist.CLIENT)
    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }
        @Override
        public Particle createParticle(SimpleParticleType t, ClientLevel level,
                                       double x, double y, double z,
                                       double vx, double vy, double vz) {
            CosmicEnergyParticle p = new CosmicEnergyParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites); return p;
        }
    }
}
