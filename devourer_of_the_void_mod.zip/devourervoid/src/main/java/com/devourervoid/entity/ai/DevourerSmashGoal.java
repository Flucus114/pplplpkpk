package com.devourervoid.entity.ai;

import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.init.ModParticles;
import com.devourervoid.init.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;

import java.util.EnumSet;
import java.util.List;

public class DevourerSmashGoal extends Goal {

    private final DevourerEntity boss;
    private int tick = 0;
    private static final int WINDUP   = 30;
    private static final int COOLDOWN = 120;

    public DevourerSmashGoal(DevourerEntity boss) {
        this.boss = boss;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = boss.getTarget();
        return t != null && boss.canAttack() && boss.distanceToSqr(t) < 16.0;
    }

    @Override
    public void start() {
        tick = 0;
        boss.playSound(ModSounds.DEVOURER_SMASH.get(), 3.0f, 0.7f);
    }

    @Override
    public boolean canContinueToUse() { return tick < WINDUP + 10; }

    @Override
    public void tick() {
        tick++;
        if (tick == WINDUP) {
            AABB area = boss.getBoundingBox().inflate(3.0, 1.0, 3.0);
            List<LivingEntity> nearby = boss.level().getEntitiesOfClass(LivingEntity.class, area);
            float dmg = (float) boss.getAttributeValue(Attributes.ATTACK_DAMAGE) * 1.5f;
            for (LivingEntity e : nearby) {
                if (e == boss) continue;
                e.hurt(boss.damageSources().mobAttack(boss), dmg);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.5, 0));
            }
            if (boss.level() instanceof ServerLevel sl) {
                for (int i = 0; i < 30; i++) {
                    sl.sendParticles(ModParticles.SCULK_SHARD.get(),
                        boss.getX() + (boss.getRandom().nextDouble()-0.5)*6,
                        boss.getY(),
                        boss.getZ() + (boss.getRandom().nextDouble()-0.5)*6,
                        1, 0, 0.2, 0, 0.1);
                }
            }
            boss.setCooldown(COOLDOWN);
        }
    }

    @Override
    public void stop() { tick = 0; }
}
