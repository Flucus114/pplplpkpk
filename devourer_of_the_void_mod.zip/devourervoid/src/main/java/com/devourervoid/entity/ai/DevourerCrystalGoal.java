package com.devourervoid.entity.ai;

import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.entity.VoidCrystalEntity;
import com.devourervoid.init.ModSounds;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

public class DevourerCrystalGoal extends Goal {

    private final DevourerEntity boss;
    private int tick = 0;
    private static final int COOLDOWN = 300;

    public DevourerCrystalGoal(DevourerEntity boss) {
        this.boss = boss;
        setFlags(EnumSet.of(Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return boss.getPhase() >= 2 && boss.canAttack() && boss.getTarget() != null;
    }

    @Override
    public void start() {
        tick = 0;
        boss.playSound(ModSounds.DEVOURER_CRYSTAL_SUMMON.get(), 3.0f, 0.7f);
    }

    @Override
    public boolean canContinueToUse() { return tick < 40; }

    @Override
    public void tick() {
        tick++;
        if (tick == 30) {
            LivingEntity target = boss.getTarget();
            if (target == null) return;
            int count = boss.getPhase() == 3 ? 5 : 3;
            for (int i = 0; i < count; i++) {
                double angle  = (2 * Math.PI / count) * i;
                double cx = boss.getX() + Math.cos(angle) * 4.0;
                double cz = boss.getZ() + Math.sin(angle) * 4.0;
                VoidCrystalEntity crystal = new VoidCrystalEntity(
                    boss.level(), cx, boss.getY() + 1, cz, target);
                boss.level().addFreshEntity(crystal);
            }
            boss.setCooldown(COOLDOWN);
        }
    }

    @Override
    public void stop() { tick = 0; }
}
