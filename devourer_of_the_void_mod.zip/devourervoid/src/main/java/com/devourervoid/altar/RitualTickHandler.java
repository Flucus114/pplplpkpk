package com.devourervoid.altar;

import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.init.ModEntities;
import com.devourervoid.init.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Mod.EventBusSubscriber
public class RitualTickHandler {

    private static final Map<BlockPos, Long> pending = new HashMap<>();

    public static void scheduleRitual(BlockPos center, long spawnAt) {
        pending.put(center, spawnAt);
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel sl)) return;

        long now = sl.getGameTime();
        Iterator<Map.Entry<BlockPos, Long>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Long> entry = it.next();
            if (entry.getValue() > now) {
                // partículas de ritual enquanto aguarda
                if (now % 4 == 0) {
                    BlockPos p = entry.getKey();
                    for (int i = 0; i < 8; i++) {
                        sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                            p.getX() + (sl.getRandom().nextDouble()-0.5)*8,
                            p.getY() + 1.0,
                            p.getZ() + (sl.getRandom().nextDouble()-0.5)*8,
                            1, 0, 0.05, 0, 0.02);
                    }
                }
                continue;
            }

            // spawn do boss
            BlockPos center = entry.getKey();
            DevourerEntity boss = ModEntities.DEVOURER.get().create(sl);
            if (boss != null) {
                boss.moveTo(center.getX()+0.5, center.getY()+1.0, center.getZ()+0.5,
                    sl.getRandom().nextFloat()*360f, 0f);
                sl.addFreshEntity(boss);
                for (int i = 0; i < 80; i++) {
                    sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                        center.getX() + (sl.getRandom().nextDouble()-0.5)*5,
                        center.getY() + sl.getRandom().nextDouble()*6,
                        center.getZ() + (sl.getRandom().nextDouble()-0.5)*5,
                        1, 0, 0.2, 0, 0.1);
                }
            }
            it.remove();
        }
    }
}
