package com.devourervoid.init;

import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.entity.VoidCrystalEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModAttributes {

    @SubscribeEvent
    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.DEVOURER.get(), DevourerEntity.createAttributes().build());
        event.put(ModEntities.VOID_CRYSTAL.get(), Monster.createMonsterAttributes().build());
    }
}
