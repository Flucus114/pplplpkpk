package com.devourervoid.init;

import com.devourervoid.DevourerMod;
import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.entity.VoidCrystalEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DevourerMod.MOD_ID);

    public static final RegistryObject<EntityType<DevourerEntity>> DEVOURER =
        ENTITIES.register("devourer_of_the_void", () ->
            EntityType.Builder.<DevourerEntity>of(DevourerEntity::new, MobCategory.MONSTER)
                .sized(3.0f, 5.5f)
                .fireImmune()
                .build(new ResourceLocation(DevourerMod.MOD_ID, "devourer_of_the_void").toString())
        );

    public static final RegistryObject<EntityType<VoidCrystalEntity>> VOID_CRYSTAL =
        ENTITIES.register("void_crystal", () ->
            EntityType.Builder.<VoidCrystalEntity>of(VoidCrystalEntity::new, MobCategory.MISC)
                .sized(0.6f, 0.6f)
                .build(new ResourceLocation(DevourerMod.MOD_ID, "void_crystal").toString())
        );
}
