package com.devourervoid;

import com.devourervoid.init.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import software.bernie.geckolib.GeckoLib;

@Mod(DevourerMod.MOD_ID)
public class DevourerMod {

    public static final String MOD_ID = "devourervoid";

    public DevourerMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        GeckoLib.initialize();

        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModParticles.PARTICLES.register(bus);

        MinecraftForge.EVENT_BUS.register(this);
    }
}
