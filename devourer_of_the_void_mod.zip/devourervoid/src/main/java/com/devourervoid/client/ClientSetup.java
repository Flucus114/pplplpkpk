package com.devourervoid.client;

import com.devourervoid.DevourerMod;
import com.devourervoid.init.ModEntities;
import com.devourervoid.init.ModParticles;
import com.devourervoid.particle.CosmicEnergyParticle;
import com.devourervoid.particle.SculkShardParticle;
import com.devourervoid.particle.VoidCrystalParticle;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DevourerMod.MOD_ID,
    bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.DEVOURER.get(),     DevourerRenderer::new);
        event.registerEntityRenderer(ModEntities.VOID_CRYSTAL.get(), VoidCrystalRenderer::new);
    }

    @SubscribeEvent
    public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.COSMIC_ENERGY.get(), CosmicEnergyParticle.Provider::new);
        event.registerSpriteSet(ModParticles.SCULK_SHARD.get(),   SculkShardParticle.Provider::new);
        event.registerSpriteSet(ModParticles.VOID_CRYSTAL.get(),   VoidCrystalParticle.Provider::new);
    }
}
