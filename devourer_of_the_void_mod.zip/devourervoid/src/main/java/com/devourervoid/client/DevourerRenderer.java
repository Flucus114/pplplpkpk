package com.devourervoid.client;

import com.devourervoid.DevourerMod;
import com.devourervoid.entity.DevourerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class DevourerRenderer extends GeoEntityRenderer<DevourerEntity> {

    public DevourerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new DevourerModel());
        this.shadowRadius = 1.5f;
    }

    @Override
    public ResourceLocation getTextureLocation(DevourerEntity entity) {
        if (entity.getPhase() == 3)
            return new ResourceLocation(DevourerMod.MOD_ID, "textures/entity/devourer_phase3.png");
        return new ResourceLocation(DevourerMod.MOD_ID, "textures/entity/devourer_of_the_void.png");
    }

    @Override
    public void render(DevourerEntity entity, float entityYaw, float partialTick,
                       PoseStack stack, MultiBufferSource buffers, int light) {
        float scale = entity.getPhase() == 3 ? 1.15f : 1.0f;
        stack.pushPose();
        stack.scale(scale, scale, scale);
        super.render(entity, entityYaw, partialTick, stack, buffers, light);
        stack.popPose();
    }
}
