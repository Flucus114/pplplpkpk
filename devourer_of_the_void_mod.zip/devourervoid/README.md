# Devourer of the Void — Forge 1.20.1

Boss cosmico corrupto das profundezas. Tres fases, 1200HP, sistema de ataques completo.

## Dependências

- Forge 1.20.1-47.3.0
- GeckoLib 4.3.4 para Forge 1.20.1

## Como compilar no GitHub (método recomendado)

1. Faça upload desta pasta como repositório no GitHub
2. O GitHub Actions em `.github/workflows/build.yml` compila automaticamente
3. Vá em **Actions → Build Mod → Run workflow**
4. Baixe o JAR em **Artifacts → devourer_of_the_void-jar**

## Como compilar localmente

Requer JDK 17 e o `gradle-wrapper.jar` na pasta `gradle/wrapper/`.

```bash
# Baixar o wrapper (necessario uma vez)
curl -L https://raw.githubusercontent.com/gradle/gradle/v8.1.1/gradle/wrapper/gradle-wrapper.jar \
     -o gradle/wrapper/gradle-wrapper.jar

# Compilar
./gradlew build

# JAR em build/libs/devourer_of_the_void-1.0.0.jar
```

## Instalação

1. Copie o JAR para a pasta `mods/`
2. Certifique-se de ter o `geckolib-forge-1.20.1-4.3.4.jar` também em `mods/`
3. Lance o Forge 1.20.1

## Invocar o boss

Monte o altar:
- Centro: `sculk_shrieker`
- 4 cantos (±3 blocos): `sculk_sensor`
- Topo do centro: `end_stone` (placeholder — troque por bloco cosmico se quiser)

Clique com botão direito no `sculk_shrieker` para iniciar o ritual.

## Texturas e Sons

As texturas em `textures/entity/` são placeholders funcionais (geradas programaticamente).
Abra o arquivo `.geo.json` no **Blockbench 4.x** com o plugin GeckoLib instalado,
esculpa os detalhes e pinte a textura 256x256 conforme a spec.

Os sons em `sounds/entity/devourer/` são silêncio. Substitua por arquivos `.ogg` reais.

## Estrutura de Fases

| Fase | HP restante | Velocidade | Ataques desbloqueados |
|------|-------------|------------|----------------------|
| 1 — Despertar  | 100% → 66% | 0.22 | Esmagamento, Rugido |
| 2 — Corrupcao  | 66% → 33%  | 0.27 | + Raio do Vazio, Cristais |
| 3 — Forma Cosmica | 33% → 0% | 0.32 | Todos, escala aumenta |
